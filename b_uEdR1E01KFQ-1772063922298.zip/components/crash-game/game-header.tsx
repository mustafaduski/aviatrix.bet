"use client"

import { Plane, Gift, Clock, Menu } from "lucide-react"

interface GameHeaderProps {
  balance: number
}

export function GameHeader({ balance }: GameHeaderProps) {
  const formatBalance = (b: number) => {
    if (b >= 1000) return `${(b / 1000).toFixed(b % 1000 === 0 ? 0 : 1)}K`
    return b.toString()
  }

  return (
    <header className="flex items-center justify-between px-4 py-3" style={{ background: '#16142a' }}>
      <button
        className="flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold"
        style={{ background: '#2d2a4a', color: '#c8c5e0' }}
      >
        <Plane className="h-4 w-4" />
        <span>Build</span>
      </button>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold"
            style={{ background: '#f5c842', color: '#1a1832' }}
          >
            {'C'}
          </div>
          <span className="text-sm font-bold" style={{ color: '#f5c842' }}>
            {formatBalance(balance)}
          </span>
        </div>

        <button className="p-1" style={{ color: '#c8c5e0' }}>
          <Gift className="h-5 w-5" />
        </button>

        <button className="p-1" style={{ color: '#c8c5e0' }}>
          <Clock className="h-5 w-5" />
        </button>

        <button className="p-1" style={{ color: '#c8c5e0' }}>
          <Menu className="h-6 w-6" />
        </button>
      </div>
    </header>
  )
}
