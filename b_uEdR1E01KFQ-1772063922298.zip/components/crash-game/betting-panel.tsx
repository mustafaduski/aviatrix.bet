"use client"

import { useState } from "react"

interface BettingPanelProps {
  panelId: number
  gameState: "waiting" | "running" | "crashed"
  multiplier: number
  onPlaceBet: (amount: number) => void
  onCashOut: () => void
  betPlaced: boolean
  cashedOut: boolean
  cashOutMultiplier: number | null
}

const QUICK_BETS = [1, 2, 5, 100]

export function BettingPanel({
  panelId,
  gameState,
  multiplier,
  onPlaceBet,
  onCashOut,
  betPlaced,
  cashedOut,
  cashOutMultiplier,
}: BettingPanelProps) {
  const [betAmount, setBetAmount] = useState(1)
  const [autoPlay, setAutoPlay] = useState(false)

  const handlePlaceBet = () => {
    onPlaceBet(betAmount)
  }

  const canPlaceBet = gameState === "waiting" && !betPlaced
  const canCashOut = gameState === "running" && betPlaced && !cashedOut
  const showCashOut = canCashOut

  return (
    <div
      className="flex flex-col gap-3 rounded-xl p-3"
      style={{ background: "#1e1c36" }}
    >
      {/* Bet Amount Input */}
      <div
        className="flex items-center justify-center gap-2 rounded-lg py-3 px-4"
        style={{ background: "#14122a" }}
      >
        <div
          className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-bold"
          style={{ background: "#f5c842", color: "#1a1832" }}
        >
          C
        </div>
        <input
          type="number"
          value={betAmount}
          onChange={(e) => setBetAmount(Math.max(1, parseInt(e.target.value) || 1))}
          className="w-full bg-transparent text-center text-lg font-bold outline-none"
          style={{ color: "#e8e6f0" }}
          min={1}
          disabled={betPlaced}
        />
      </div>

      {/* Quick Bet Buttons */}
      <div className="grid grid-cols-4 gap-2">
        {QUICK_BETS.map((amount) => (
          <button
            key={`${panelId}-${amount}`}
            onClick={() => !betPlaced && setBetAmount(amount)}
            disabled={betPlaced}
            className="rounded-lg py-2 text-sm font-semibold transition-all active:scale-95 disabled:opacity-50"
            style={{ background: "#2d2a4a", color: "#c8c5e0" }}
          >
            {amount}
          </button>
        ))}
      </div>

      {/* Place Bet / Cash Out Button */}
      {showCashOut ? (
        <button
          onClick={onCashOut}
          className="rounded-xl py-4 text-base font-bold uppercase tracking-wide transition-all active:scale-[0.98]"
          style={{
            background: "linear-gradient(135deg, #22c55e 0%, #16a34a 100%)",
            color: "#ffffff",
          }}
        >
          CASH OUT {(betAmount * multiplier).toFixed(2)}
        </button>
      ) : (
        <button
          onClick={handlePlaceBet}
          disabled={!canPlaceBet}
          className="rounded-xl py-4 text-base font-bold uppercase tracking-wide transition-all active:scale-[0.98] disabled:opacity-40"
          style={{
            background: canPlaceBet
              ? "linear-gradient(135deg, #5b6aff 0%, #7c5cfc 100%)"
              : betPlaced && !cashedOut
                ? "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)"
                : cashedOut
                  ? "linear-gradient(135deg, #22c55e 0%, #16a34a 100%)"
                  : "linear-gradient(135deg, #5b6aff 0%, #7c5cfc 100%)",
            color: "#ffffff",
          }}
        >
          {cashedOut
            ? `WON ${(betAmount * (cashOutMultiplier || 1)).toFixed(2)}`
            : betPlaced
              ? "WAITING..."
              : "PLACE BET"}
        </button>
      )}

      {/* Auto Play Toggle */}
      <div className="flex items-center justify-between px-1">
        <span className="text-sm" style={{ color: "#8b87a8" }}>
          Auto play
        </span>
        <button
          onClick={() => setAutoPlay(!autoPlay)}
          className="relative h-6 w-11 rounded-full transition-colors"
          style={{ background: autoPlay ? "#5b6aff" : "#2d2a4a" }}
        >
          <div
            className="absolute top-0.5 h-5 w-5 rounded-full transition-transform"
            style={{
              background: "#c8c5e0",
              transform: autoPlay ? "translateX(22px)" : "translateX(2px)",
            }}
          />
        </button>
      </div>
    </div>
  )
}
