"use client"

import { useRef, useEffect, useCallback } from "react"

interface GameCanvasProps {
  multiplier: number
  gameState: "waiting" | "running" | "crashed"
  elapsed: number
}

export function GameCanvas({ multiplier, gameState, elapsed }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animFrameRef = useRef<number>(0)

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    const w = rect.width
    const h = rect.height

    // Background - sky gradient (warm tones like the image)
    const skyGrad = ctx.createLinearGradient(0, 0, 0, h)
    skyGrad.addColorStop(0, "#e8c4a0")
    skyGrad.addColorStop(0.2, "#d4a67a")
    skyGrad.addColorStop(0.4, "#b8906a")
    skyGrad.addColorStop(0.55, "#8a7050")
    skyGrad.addColorStop(0.7, "#4a3d40")
    skyGrad.addColorStop(0.8, "#2a2440")
    skyGrad.addColorStop(1.0, "#1a1832")
    ctx.fillStyle = skyGrad
    ctx.fillRect(0, 0, w, h)

    // Desert hills silhouette
    ctx.fillStyle = "#7a5e45"
    ctx.beginPath()
    ctx.moveTo(0, h * 0.45)
    ctx.quadraticCurveTo(w * 0.15, h * 0.35, w * 0.3, h * 0.42)
    ctx.quadraticCurveTo(w * 0.5, h * 0.48, w * 0.65, h * 0.38)
    ctx.quadraticCurveTo(w * 0.8, h * 0.32, w, h * 0.4)
    ctx.lineTo(w, h * 0.55)
    ctx.lineTo(0, h * 0.55)
    ctx.closePath()
    ctx.fill()

    // Ground/runway area
    const groundY = h * 0.55
    const runwayGrad = ctx.createLinearGradient(0, groundY, 0, h)
    runwayGrad.addColorStop(0, "#3a3555")
    runwayGrad.addColorStop(0.3, "#2a2545")
    runwayGrad.addColorStop(1, "#1a1832")
    ctx.fillStyle = runwayGrad
    ctx.fillRect(0, groundY, w, h - groundY)

    // Runway line
    ctx.strokeStyle = "rgba(100, 95, 140, 0.3)"
    ctx.lineWidth = 2
    ctx.setLineDash([12, 8])
    ctx.beginPath()
    ctx.moveTo(0, groundY + 5)
    ctx.lineTo(w, groundY + 5)
    ctx.stroke()
    ctx.setLineDash([])

    // Grid overlay area
    const gridLeft = 24
    const gridRight = w - 24
    const gridTop = groundY + 15
    const gridBottom = h - 20

    // Grid border
    ctx.strokeStyle = "rgba(70, 65, 110, 0.4)"
    ctx.lineWidth = 1
    ctx.strokeRect(gridLeft, gridTop, gridRight - gridLeft, gridBottom - gridTop)

    // Grid lines (subtle)
    ctx.strokeStyle = "rgba(70, 65, 110, 0.2)"
    ctx.lineWidth = 0.5
    const gridCols = 6
    const gridRows = 3
    for (let i = 1; i < gridCols; i++) {
      const x = gridLeft + (i / gridCols) * (gridRight - gridLeft)
      ctx.beginPath()
      ctx.moveTo(x, gridTop)
      ctx.lineTo(x, gridBottom)
      ctx.stroke()
    }
    for (let i = 1; i < gridRows; i++) {
      const y = gridTop + (i / gridRows) * (gridBottom - gridTop)
      ctx.beginPath()
      ctx.moveTo(gridLeft, y)
      ctx.lineTo(gridRight, y)
      ctx.stroke()
    }

    // Draw the multiplier curve if game is running or crashed
    if (gameState === "running" || gameState === "crashed") {
      const maxTime = 15
      const progress = Math.min(elapsed / maxTime, 0.95)
      const curvePoints: { x: number; y: number }[] = []
      const steps = Math.max(2, Math.floor(progress * 200))

      for (let i = 0; i <= steps; i++) {
        const t = i / 200
        const x = gridLeft + t * (gridRight - gridLeft)
        // Exponential curve
        const multAt = Math.pow(Math.E, t * maxTime * 0.15)
        const normalizedY = Math.min((multAt - 1) / 8, 1)
        const y = gridBottom - normalizedY * (gridBottom - gridTop - 10)
        curvePoints.push({ x, y: Math.max(gridTop + 5, y) })
      }

      if (curvePoints.length > 1) {
        // Glow under curve
        ctx.beginPath()
        ctx.moveTo(curvePoints[0].x, gridBottom)
        curvePoints.forEach((p) => ctx.lineTo(p.x, p.y))
        ctx.lineTo(curvePoints[curvePoints.length - 1].x, gridBottom)
        ctx.closePath()
        const fillGrad = ctx.createLinearGradient(0, gridTop, 0, gridBottom)
        fillGrad.addColorStop(0, "rgba(91, 106, 255, 0.12)")
        fillGrad.addColorStop(1, "rgba(91, 106, 255, 0.01)")
        ctx.fillStyle = fillGrad
        ctx.fill()

        // Curve line with glow
        ctx.shadowColor = gameState === "crashed" ? "#ef4444" : "#5b6aff"
        ctx.shadowBlur = 6
        ctx.beginPath()
        curvePoints.forEach((p, i) => {
          if (i === 0) ctx.moveTo(p.x, p.y)
          else ctx.lineTo(p.x, p.y)
        })
        ctx.strokeStyle = gameState === "crashed" ? "#ef4444" : "rgba(200, 200, 230, 0.7)"
        ctx.lineWidth = 2.5
        ctx.stroke()
        ctx.shadowBlur = 0

        // Airplane at end of curve
        const lastPoint = curvePoints[curvePoints.length - 1]
        const prevIdx = Math.max(0, curvePoints.length - 6)
        const prevPoint = curvePoints[prevIdx]
        const angle = Math.atan2(lastPoint.y - prevPoint.y, lastPoint.x - prevPoint.x)

        drawBiplane(ctx, lastPoint.x, lastPoint.y, angle, gameState === "crashed")
      }
    } else {
      // Waiting state - airplane on ground in the sky area
      const planeX = w * 0.45
      const planeY = groundY - 35
      drawBiplane(ctx, planeX, planeY, -0.05, false)
    }

    // Info display in grid area (bottom left)
    if (gameState === "waiting") {
      ctx.font = "16px Geist, system-ui, sans-serif"
      ctx.fillStyle = "#8b87a8"
      ctx.fillText("\u2708", gridLeft + 12, gridBottom - 16)
      ctx.font = "bold 22px Geist, system-ui, sans-serif"
      ctx.fillStyle = "#c8c5e0"
      ctx.fillText("680", gridLeft + 35, gridBottom - 14)
      ctx.font = "12px Geist, system-ui, sans-serif"
      ctx.fillStyle = "#6b678a"
      ctx.fillText("\u25C7", gridLeft + 88, gridBottom - 14)
    }

  }, [multiplier, gameState, elapsed])

  useEffect(() => {
    const render = () => {
      draw()
      animFrameRef.current = requestAnimationFrame(render)
    }
    render()
    return () => cancelAnimationFrame(animFrameRef.current)
  }, [draw])

  return (
    <div className="relative w-full" style={{ aspectRatio: "4/5" }}>
      <canvas
        ref={canvasRef}
        className="h-full w-full"
        style={{ display: "block" }}
      />
    </div>
  )
}

function drawBiplane(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  angle: number,
  crashed: boolean
) {
  ctx.save()
  ctx.translate(x, y)
  ctx.rotate(angle)

  const s = 1.1 // scale

  // Shadow
  ctx.fillStyle = "rgba(0,0,0,0.2)"
  ctx.beginPath()
  ctx.ellipse(2 * s, 4 * s, 28 * s, 6 * s, 0, 0, Math.PI * 2)
  ctx.fill()

  // Fuselage body (red)
  ctx.fillStyle = crashed ? "#8a2020" : "#cc3333"
  ctx.beginPath()
  ctx.moveTo(-28 * s, 0)
  ctx.quadraticCurveTo(-28 * s, -10 * s, -10 * s, -10 * s)
  ctx.lineTo(20 * s, -8 * s)
  ctx.quadraticCurveTo(30 * s, -6 * s, 32 * s, 0)
  ctx.quadraticCurveTo(30 * s, 6 * s, 20 * s, 8 * s)
  ctx.lineTo(-10 * s, 10 * s)
  ctx.quadraticCurveTo(-28 * s, 10 * s, -28 * s, 0)
  ctx.closePath()
  ctx.fill()

  // Fuselage highlight
  ctx.fillStyle = crashed ? "#aa3030" : "#e04040"
  ctx.beginPath()
  ctx.moveTo(-20 * s, -8 * s)
  ctx.quadraticCurveTo(0, -10 * s, 20 * s, -7 * s)
  ctx.lineTo(20 * s, -3 * s)
  ctx.quadraticCurveTo(0, -5 * s, -20 * s, -3 * s)
  ctx.closePath()
  ctx.fill()

  // Cockpit windshield
  ctx.fillStyle = "#f0e8d8"
  ctx.beginPath()
  ctx.moveTo(18 * s, -7 * s)
  ctx.quadraticCurveTo(26 * s, -8 * s, 30 * s, -3 * s)
  ctx.quadraticCurveTo(30 * s, 2 * s, 26 * s, 3 * s)
  ctx.lineTo(20 * s, 2 * s)
  ctx.closePath()
  ctx.fill()

  // Cockpit glass reflection
  ctx.fillStyle = "rgba(180, 220, 255, 0.3)"
  ctx.beginPath()
  ctx.moveTo(22 * s, -5 * s)
  ctx.quadraticCurveTo(26 * s, -6 * s, 28 * s, -2 * s)
  ctx.lineTo(24 * s, -1 * s)
  ctx.closePath()
  ctx.fill()

  // Top wing
  ctx.fillStyle = crashed ? "#772020" : "#bb2828"
  ctx.beginPath()
  ctx.roundRect(-12 * s, -20 * s, 30 * s, 8 * s, 2 * s)
  ctx.fill()

  // Wing stripes (white)
  ctx.fillStyle = "rgba(255,255,255,0.15)"
  ctx.fillRect(-8 * s, -19 * s, 26 * s, 2 * s)

  // Bottom wing
  ctx.fillStyle = crashed ? "#772020" : "#bb2828"
  ctx.beginPath()
  ctx.roundRect(-12 * s, 12 * s, 30 * s, 8 * s, 2 * s)
  ctx.fill()

  // Wing struts
  ctx.strokeStyle = crashed ? "#663333" : "#996666"
  ctx.lineWidth = 1.5 * s
  ctx.beginPath()
  ctx.moveTo(-4 * s, -12 * s)
  ctx.lineTo(-4 * s, 12 * s)
  ctx.moveTo(10 * s, -12 * s)
  ctx.lineTo(10 * s, 12 * s)
  ctx.stroke()

  // Tail fin (blue)
  ctx.fillStyle = crashed ? "#1a3060" : "#2a4a8a"
  ctx.beginPath()
  ctx.moveTo(-24 * s, -3 * s)
  ctx.lineTo(-30 * s, -16 * s)
  ctx.lineTo(-22 * s, -16 * s)
  ctx.lineTo(-18 * s, -3 * s)
  ctx.closePath()
  ctx.fill()

  // Horizontal stabilizer
  ctx.fillStyle = crashed ? "#1a3060" : "#2a4a8a"
  ctx.beginPath()
  ctx.moveTo(-26 * s, -1 * s)
  ctx.lineTo(-34 * s, -5 * s)
  ctx.lineTo(-34 * s, 5 * s)
  ctx.lineTo(-26 * s, 1 * s)
  ctx.closePath()
  ctx.fill()

  // Engine cowling
  ctx.fillStyle = "#555"
  ctx.beginPath()
  ctx.arc(32 * s, 0, 4 * s, 0, Math.PI * 2)
  ctx.fill()

  // Spinning propeller
  if (!crashed) {
    const propAngle = Date.now() / 30
    ctx.save()
    ctx.translate(34 * s, 0)
    ctx.rotate(propAngle)
    ctx.fillStyle = "rgba(80, 80, 80, 0.7)"
    ctx.beginPath()
    ctx.ellipse(0, 0, 2 * s, 14 * s, 0, 0, Math.PI * 2)
    ctx.fill()
    ctx.fillStyle = "rgba(80, 80, 80, 0.5)"
    ctx.beginPath()
    ctx.ellipse(0, 0, 14 * s, 2 * s, 0, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }

  // Landing gear
  ctx.strokeStyle = "#555"
  ctx.lineWidth = 2 * s
  ctx.beginPath()
  ctx.moveTo(-5 * s, 10 * s)
  ctx.lineTo(-8 * s, 22 * s)
  ctx.moveTo(10 * s, 10 * s)
  ctx.lineTo(7 * s, 22 * s)
  ctx.stroke()

  // Wheels
  ctx.fillStyle = "#333"
  ctx.beginPath()
  ctx.arc(-8 * s, 23 * s, 3 * s, 0, Math.PI * 2)
  ctx.fill()
  ctx.beginPath()
  ctx.arc(7 * s, 23 * s, 3 * s, 0, Math.PI * 2)
  ctx.fill()

  ctx.restore()
}
