"use client"

interface GameHistoryProps {
  history: number[]
}

export function GameHistory({ history }: GameHistoryProps) {
  const getColor = (value: number) => {
    if (value >= 10) return "#a855f7"
    if (value >= 5) return "#22c55e"
    if (value >= 2) return "#22c55e"
    return "#ef4444"
  }

  return (
    <div
      className="history-scroll flex items-center gap-3 overflow-x-auto px-4 py-2"
      style={{ background: "#0f0e1a" }}
    >
      {history.map((value, index) => (
        <span
          key={index}
          className="shrink-0 text-sm font-bold"
          style={{ color: getColor(value) }}
        >
          {value.toFixed(2)}
        </span>
      ))}
    </div>
  )
}
