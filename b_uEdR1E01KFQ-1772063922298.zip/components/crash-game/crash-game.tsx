"use client"

import { useState, useRef, useCallback, useEffect } from "react"
import { GameHeader } from "@/components/crash-game/game-header"
import { GameCanvas } from "@/components/crash-game/game-canvas"
import { BettingPanel } from "@/components/crash-game/betting-panel"
import { GameHistory } from "@/components/crash-game/game-history"

type GameState = "waiting" | "running" | "crashed"

interface PanelState {
  betPlaced: boolean
  betAmount: number
  cashedOut: boolean
  cashOutMultiplier: number | null
}

const INITIAL_HISTORY = [2.03, 37.29, 3.93, 6.51, 1.04, 3.3, 2.72, 1.2, 1.11, 35.05, 4.22, 1.87, 12.5]

export default function CrashGame() {
  const [balance, setBalance] = useState(1000)
  const [gameState, setGameState] = useState<GameState>("waiting")
  const [multiplier, setMultiplier] = useState(1.0)
  const [elapsed, setElapsed] = useState(0)
  const [history, setHistory] = useState<number[]>(INITIAL_HISTORY)
  const [countdown, setCountdown] = useState<number | null>(null)

  const [panels, setPanels] = useState<[PanelState, PanelState]>([
    { betPlaced: false, betAmount: 0, cashedOut: false, cashOutMultiplier: null },
    { betPlaced: false, betAmount: 0, cashedOut: false, cashOutMultiplier: null },
  ])

  const crashPointRef = useRef(0)
  const gameLoopRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const startTimeRef = useRef(0)
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const generateCrashPoint = () => {
    const r = Math.random()
    if (r < 0.03) return 1.0
    return Math.max(1.0, parseFloat((1 / (1 - r) * 0.97).toFixed(2)))
  }

  const startGame = useCallback(() => {
    crashPointRef.current = generateCrashPoint()
    startTimeRef.current = Date.now()
    setGameState("running")
    setMultiplier(1.0)
    setElapsed(0)
    setCountdown(null)

    gameLoopRef.current = setInterval(() => {
      const now = Date.now()
      const elapsedSec = (now - startTimeRef.current) / 1000
      setElapsed(elapsedSec)

      const newMultiplier = parseFloat(Math.pow(Math.E, elapsedSec * 0.15).toFixed(2))
      setMultiplier(newMultiplier)

      if (newMultiplier >= crashPointRef.current) {
        if (gameLoopRef.current) clearInterval(gameLoopRef.current)
        setMultiplier(crashPointRef.current)
        setGameState("crashed")

        setHistory((prev) => [crashPointRef.current, ...prev].slice(0, 20))

        setTimeout(() => {
          setPanels([
            { betPlaced: false, betAmount: 0, cashedOut: false, cashOutMultiplier: null },
            { betPlaced: false, betAmount: 0, cashedOut: false, cashOutMultiplier: null },
          ])
          setGameState("waiting")
          setMultiplier(1.0)
          setElapsed(0)
          setCountdown(5)
        }, 2500)
      }
    }, 50)
  }, [])

  useEffect(() => {
    if (countdown !== null && countdown > 0) {
      countdownRef.current = setInterval(() => {
        setCountdown((prev) => {
          if (prev !== null && prev <= 1) {
            if (countdownRef.current) clearInterval(countdownRef.current)
            startGame()
            return null
          }
          return prev !== null ? prev - 1 : null
        })
      }, 1000)

      return () => {
        if (countdownRef.current) clearInterval(countdownRef.current)
      }
    }
  }, [countdown, startGame])

  useEffect(() => {
    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current)
      if (countdownRef.current) clearInterval(countdownRef.current)
    }
  }, [])

  const handlePlaceBet = (panelIndex: number, amount: number) => {
    if (gameState !== "waiting") return
    if (amount > balance) return

    setBalance((prev) => prev - amount)
    setPanels((prev) => {
      const updated = [...prev] as [PanelState, PanelState]
      updated[panelIndex] = {
        betPlaced: true,
        betAmount: amount,
        cashedOut: false,
        cashOutMultiplier: null,
      }
      return updated
    })

    if (countdown === null && gameState === "waiting") {
      setCountdown(3)
    }
  }

  const handleCashOut = (panelIndex: number) => {
    if (gameState !== "running") return
    if (!panels[panelIndex].betPlaced || panels[panelIndex].cashedOut) return

    const winnings = panels[panelIndex].betAmount * multiplier
    setBalance((prev) => prev + parseFloat(winnings.toFixed(2)))

    setPanels((prev) => {
      const updated = [...prev] as [PanelState, PanelState]
      updated[panelIndex] = {
        ...updated[panelIndex],
        cashedOut: true,
        cashOutMultiplier: multiplier,
      }
      return updated
    })
  }

  return (
    <div
      className="mx-auto flex min-h-screen max-w-[480px] flex-col overflow-hidden"
      style={{ background: "#0f0e1a" }}
    >
      <GameHeader balance={balance} />

      {/* Game Canvas Area */}
      <div className="relative flex-shrink-0">
        <GameCanvas
          multiplier={multiplier}
          gameState={gameState}
          elapsed={elapsed}
        />

        {/* Multiplier overlay */}
        {gameState === "running" && (
          <div className="pointer-events-none absolute inset-0 flex items-start justify-center pt-6">
            <div
              className="rounded-xl px-6 py-2"
              style={{ background: "rgba(15, 14, 26, 0.7)", backdropFilter: "blur(4px)" }}
            >
              <p
                className="text-center text-4xl font-black tabular-nums"
                style={{
                  color: multiplier >= 2 ? "#22c55e" : "#ffffff",
                  textShadow: multiplier >= 2
                    ? "0 0 20px rgba(34, 197, 94, 0.4)"
                    : "0 2px 10px rgba(0,0,0,0.5)",
                }}
              >
                {multiplier.toFixed(2)}x
              </p>
            </div>
          </div>
        )}

        {/* Crashed overlay */}
        {gameState === "crashed" && (
          <div className="pointer-events-none absolute inset-0 flex items-start justify-center pt-6">
            <div
              className="rounded-xl px-6 py-3 text-center"
              style={{ background: "rgba(15, 14, 26, 0.85)", backdropFilter: "blur(4px)" }}
            >
              <p className="text-lg font-bold" style={{ color: "#ef4444" }}>
                FLEW AWAY!
              </p>
              <p className="text-3xl font-black" style={{ color: "#ef4444" }}>
                {multiplier.toFixed(2)}x
              </p>
            </div>
          </div>
        )}

        {/* Countdown overlay */}
        {gameState === "waiting" && countdown !== null && (
          <div className="pointer-events-none absolute inset-0 flex items-start justify-center pt-6">
            <div
              className="rounded-xl px-6 py-3 text-center"
              style={{ background: "rgba(15, 14, 26, 0.7)", backdropFilter: "blur(4px)" }}
            >
              <p className="text-sm font-semibold" style={{ color: "#8b87a8" }}>
                Next round in
              </p>
              <p
                className="text-4xl font-black tabular-nums"
                style={{ color: "#5b6aff", textShadow: "0 0 20px rgba(91, 106, 255, 0.4)" }}
              >
                {countdown}s
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Betting Panels */}
      <div className="grid grid-cols-2 gap-2 px-2 py-2">
        <BettingPanel
          panelId={1}
          gameState={gameState}
          multiplier={multiplier}
          onPlaceBet={(amount) => handlePlaceBet(0, amount)}
          onCashOut={() => handleCashOut(0)}
          betPlaced={panels[0].betPlaced}
          cashedOut={panels[0].cashedOut}
          cashOutMultiplier={panels[0].cashOutMultiplier}
        />
        <BettingPanel
          panelId={2}
          gameState={gameState}
          multiplier={multiplier}
          onPlaceBet={(amount) => handlePlaceBet(1, amount)}
          onCashOut={() => handleCashOut(1)}
          betPlaced={panels[1].betPlaced}
          cashedOut={panels[1].cashedOut}
          cashOutMultiplier={panels[1].cashOutMultiplier}
        />
      </div>

      {/* History */}
      <GameHistory history={history} />
    </div>
  )
}
