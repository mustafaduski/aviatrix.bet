import CrashGame from "@/components/crash-game/crash-game"

export default function Page() {
  return <CrashGame />
}
